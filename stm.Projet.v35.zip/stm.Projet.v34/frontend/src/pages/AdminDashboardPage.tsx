import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { MapView as MapComponent } from '../components/MapView';
import { TopBar } from '../components/shared/TopBar';
import { Sidebar } from '../components/Sidebar';
import { io } from 'socket.io-client';
import { Bus, Activity, AlertCircle, Plus, Pencil, Save, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const emptyBusForm = {
  plate_number: '',
  driver_name_en: '',
  receveur_name_en: '',
  from_en: '',
  to_en: '',
  eta_en: '5 min',
  capacity: 40,
  passengers: 0,
  status: 'working',
  next_maintenance_date: '',
  maintenance_note: '',
  bus_type: 'Standard',
};

export const AdminDashboardPage: React.FC = () => {
  const { logout, token } = useAuth();
  const { t } = useLanguage();
  const [buses, setBuses] = useState<any[]>([]);
  const [stops, setStops] = useState<any[]>([]);
  const [complaints, setComplaints] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [showSidebar, setShowSidebar] = useState(false);
  const [showBusEditor, setShowBusEditor] = useState(false);
  const [editingBus, setEditingBus] = useState<any | null>(null);
  const [busForm, setBusForm] = useState<any>(emptyBusForm);
  const [formError, setFormError] = useState('');

  const fetchBuses = async () => {
    const res = await fetch('/api/buses');
    const data = await res.json();
    if (Array.isArray(data)) setBuses(data);
  };

  useEffect(() => {
    fetchBuses().catch(() => {});
    fetch('/api/buses/stops').then(res => res.json()).then(data => {
      if (Array.isArray(data)) setStops(data);
    }).catch(() => {});
    fetch('/api/complaints', {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => res.json()).then(data => {
      if (Array.isArray(data)) setComplaints(data);
    }).catch(() => {});

    const socket = io();
    socket.on('bus_positions', (data) => setBuses(data));
    socket.on('alert', (alert) => setAlerts(prev => [alert, ...prev].slice(0, 10)));
    socket.on('new_complaint', (complaint) => setComplaints(prev => [complaint, ...prev]));

    return () => { socket.disconnect(); };
  }, [token]);

  const chartData = [
    { name: 'Daily', working: 72, delayed: 18, out: 10 },
    { name: 'Weekly', working: 78, delayed: 15, out: 7 },
    { name: 'Monthly', working: 82, delayed: 12, out: 6 }
  ];

  const openAddBus = () => {
    setEditingBus(null);
    setBusForm(emptyBusForm);
    setFormError('');
    setShowBusEditor(true);
  };

  const openEditBus = (bus: any) => {
    setEditingBus(bus);
    setBusForm({
      plate_number: bus.plate_number || '',
      driver_name_en: bus.driver_name_en || bus.driver_name || '',
      receveur_name_en: bus.receveur_name_en || bus.receveur_name || '',
      from_en: bus.from_en || '',
      to_en: bus.to_en || '',
      eta_en: bus.eta_en || '5 min',
      capacity: bus.capacity || 40,
      passengers: bus.status === 'out_of_service' ? 0 : (bus.occupancy ?? bus.passengers ?? 0),
      status: bus.status || 'working',
      next_maintenance_date: bus.next_maintenance_date || '',
      maintenance_note: bus.maintenance_note || '',
      bus_type: bus.bus_type || 'Standard',
    });
    setFormError('');
    setShowBusEditor(true);
  };

  const handleBusFormChange = (key: string, value: any) => {
    setBusForm((prev: any) => {
      const next = { ...prev, [key]: value };
      if (key === 'status' && value === 'out_of_service') next.passengers = 0;
      if (key === 'capacity') next.passengers = Math.min(Number(next.passengers || 0), Number(value || 0));
      return next;
    });
  };

  const saveBus = async () => {
    setFormError('');
    if (!busForm.plate_number.trim()) return setFormError('Plate number is required.');
    if (!busForm.driver_name_en.trim()) return setFormError('Driver name is required.');

    const payload = {
      ...busForm,
      driver_name_fr: busForm.driver_name_en,
      driver_name_ar: busForm.driver_name_en,
      receveur_name_fr: busForm.receveur_name_en,
      receveur_name_ar: busForm.receveur_name_en,
      from_fr: busForm.from_en,
      from_ar: busForm.from_en,
      to_fr: busForm.to_en,
      to_ar: busForm.to_en,
      eta_fr: busForm.eta_en,
      eta_ar: busForm.eta_en,
      capacity: Number(busForm.capacity || 0),
      passengers: busForm.status === 'out_of_service' ? 0 : Number(busForm.passengers || 0),
    };

    const res = await fetch(editingBus ? `/api/buses/${editingBus.id}` : '/api/buses', {
      method: editingBus ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setFormError(data.error || 'Unable to save bus information.');

    await fetchBuses();
    setShowBusEditor(false);
  };

  const getMaintenanceStatus = (dateString: string) => {
    if (!dateString) return { label: 'Unknown', color: 'bg-slate-100 text-slate-800 dark:bg-brand-purple-card dark:text-brand-text-secondary border-slate-300' };
    const date = new Date(dateString);
    const today = new Date();
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { label: t('overdue') || 'Overdue', color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 border-red-200 dark:border-red-800/50' };
    if (diffDays <= 7) return { label: t('due_soon') || 'Due soon', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800/50' };
    return { label: t('good') || 'Good', color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800/50' };
  };

  const inputClass = 'w-full rounded-2xl border border-slate-200 dark:border-brand-purple-dark bg-white dark:bg-brand-purple-dark/70 px-4 py-3 text-sm font-bold text-slate-900 dark:text-white outline-none focus:border-brand-gold';

  return (
    <div className="min-h-screen md:h-screen w-full flex flex-col md:flex-row bg-transparent transition-colors duration-300 md:overflow-hidden">
      <TopBar onMenuClick={() => setShowSidebar(true)} />

      <Sidebar showSidebar={showSidebar} buses={buses} alerts={alerts} logout={logout} />
      {showSidebar && (
        <div className="fixed inset-0 z-[10000] bg-brand-purple-dark/60 backdrop-blur-sm md:hidden" onClick={() => setShowSidebar(false)} />
      )}

      <main className="flex-1 flex flex-col md:h-screen overflow-y-auto px-4 pb-8 pt-20 md:p-8 gap-5 md:gap-8 custom-scrollbar bg-transparent">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 md:gap-8">
          <div className="xl:col-span-2 bg-white dark:bg-brand-purple-card rounded-[2rem] md:rounded-[2.5rem] border border-slate-200 dark:border-brand-purple-dark overflow-hidden shadow-2xl shadow-slate-200/50 dark:shadow-none flex flex-col min-h-[420px] md:min-h-[500px]">
            <div className="p-4 md:p-6 border-b border-slate-200 dark:border-brand-purple-dark bg-white/50 dark:bg-brand-purple-card/50 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-brand-gold/10 p-3 rounded-2xl"><Activity className="w-5 h-5 text-brand-gold" /></div>
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base md:text-lg tracking-tight uppercase">Live Operations</h3>
                  <p className="text-[10px] font-black text-slate-900 dark:text-brand-text-secondary uppercase tracking-widest leading-none mt-1">Real-time Telemetry</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 bg-brand-gold/10 dark:bg-brand-gold/20 border border-brand-gold/20 rounded-full">
                <div className="w-2 h-2 rounded-full bg-brand-gold animate-pulse"></div>
                <span className="text-[10px] font-black text-brand-gold-soft dark:text-brand-gold uppercase tracking-widest">Active</span>
              </div>
            </div>
            <div className="flex-1 relative">{stops.length > 0 && <MapComponent buses={buses} stops={stops} isAdmin={true} />}</div>
          </div>

          <div className="bg-white dark:bg-brand-purple-card rounded-[2rem] md:rounded-[2.5rem] border border-slate-200 dark:border-brand-purple-dark p-5 md:p-8 shadow-2xl shadow-slate-200/50 dark:shadow-none flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-4 mb-5 md:mb-8">
                <div className="bg-brand-gold/10 p-3 rounded-2xl"><Activity className="w-5 h-5 text-brand-gold" /></div>
                <div>
                  <h3 className="font-extrabold text-slate-900 dark:text-white text-base md:text-lg tracking-tight uppercase line-clamp-1">Performance</h3>
                  <p className="text-[10px] font-black text-slate-900 dark:text-brand-text-secondary uppercase tracking-widest leading-none mt-1">Daily · Weekly · Monthly</p>
                </div>
              </div>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" className="dark:stroke-brand-purple-dark" vertical={false} />
                    <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} className="font-black uppercase tracking-widest" />
                    <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} className="font-black uppercase tracking-widest" />
                    <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: 'none', borderRadius: '1.5rem', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', color: '#0f172a', fontWeight: 'bold' }} />
                    <Line type="monotone" dataKey="working" stroke="#059669" strokeWidth={4} name="Working %" dot={{ r: 4, fill: '#059669', strokeWidth: 0 }} activeDot={{ r: 6, strokeWidth: 0 }} />
                    <Line type="monotone" dataKey="delayed" stroke="#d4af37" strokeWidth={4} name="Delayed %" dot={{ r: 4, fill: '#d4af37', strokeWidth: 0 }} activeDot={{ r: 6, strokeWidth: 0 }} />
                    <Line type="monotone" dataKey="out" stroke="#dc2626" strokeWidth={4} name="Out of service %" dot={{ r: 4, fill: '#dc2626', strokeWidth: 0 }} activeDot={{ r: 6, strokeWidth: 0 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-brand-purple-card rounded-[2rem] md:rounded-[2.5rem] border border-slate-200 dark:border-brand-purple-dark p-5 md:p-8 shadow-2xl shadow-slate-200/50 dark:shadow-none mb-12">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-5 md:mb-8">
            <div className="flex items-center gap-4">
              <div className="bg-brand-gold/10 p-3 rounded-2xl"><Bus className="w-5 h-5 text-brand-gold" /></div>
              <div>
                <h3 className="font-black text-slate-900 dark:text-white text-lg md:text-xl tracking-[0.08em] md:tracking-[0.12em] uppercase">Bus Information Center</h3>
                <p className="text-[10px] font-black text-slate-900 dark:text-brand-text-secondary uppercase tracking-widest mt-1">Plates · Drivers · Receveurs · Routes · Occupancy · Live status</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-4 py-2 rounded-full bg-brand-gold/10 text-brand-gold-soft dark:text-brand-gold border border-brand-gold/20 text-[10px] font-black uppercase tracking-widest">{buses.length} registered units</span>
              <button onClick={openAddBus} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-gold text-brand-purple-dark text-[10px] font-black uppercase tracking-widest hover:opacity-90 transition-all">
                <Plus className="w-4 h-4" /> Add bus
              </button>
            </div>
          </div>

          {buses.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-slate-300 dark:border-brand-purple-dark p-10 text-center">
              <p className="text-sm font-black text-slate-900 dark:text-brand-text-secondary uppercase tracking-widest">Waiting for bus data from API / simulator...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 2xl:grid-cols-3 gap-4 md:gap-5">
              {buses.map(bus => {
                const occupancy = bus.status === 'out_of_service' ? 0 : (bus.occupancy ?? bus.passengers ?? 0);
                const capacity = bus.capacity ?? 0;
                const ratio = capacity ? Math.min(100, Math.round((occupancy / capacity) * 100)) : 0;
                const statusStyle = bus.status === 'out_of_service'
                  ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-900/40'
                  : bus.status === 'delayed'
                    ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-900/40'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300 dark:border-emerald-900/40';

                return (
                  <article key={`admin-bus-card-${bus.id}`} className="rounded-3xl border border-slate-200 dark:border-brand-purple-dark bg-slate-50/80 dark:bg-brand-purple-dark/40 p-4 md:p-5 hover:border-brand-gold/40 transition-all shadow-sm">
                    <div className="flex items-start justify-between gap-4 mb-5">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-brand-gold-soft dark:text-brand-gold mb-1">Plate number</p>
                        <h4 className="text-xl md:text-2xl font-black text-slate-950 dark:text-white tracking-tight">{bus.plate_number}</h4>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <span className={`px-3 py-1.5 rounded-full border text-[10px] font-black uppercase tracking-widest ${statusStyle}`}>{bus.status || 'working'}</span>
                        <button onClick={() => openEditBus(bus)} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border border-brand-gold/30 text-brand-gold text-[10px] font-black uppercase tracking-widest hover:bg-brand-gold/10">
                          <Pencil className="w-3 h-3" /> Edit
                        </button>
                      </div>
                    </div>

                    <div className="space-y-3 text-sm font-black text-slate-900 dark:text-brand-text-secondary">
                      <div className="flex justify-between gap-3"><span className="uppercase tracking-widest text-[10px] opacity-70">Driver</span><span className="text-right text-slate-950 dark:text-white">{bus.driver_name_en || bus.driver_name || '—'}</span></div>
                      <div className="flex justify-between gap-3"><span className="uppercase tracking-widest text-[10px] opacity-70">Receveur</span><span className="text-right text-slate-950 dark:text-white">{bus.receveur_name_en || '—'}</span></div>
                      <div className="flex justify-between gap-3"><span className="uppercase tracking-widest text-[10px] opacity-70">Route</span><span className="text-right text-slate-950 dark:text-white">{bus.from_en || '—'} → {bus.to_en || '—'}</span></div>
                      <div className="flex justify-between gap-3"><span className="uppercase tracking-widest text-[10px] opacity-70">ETA</span><span className="text-right text-brand-gold-soft dark:text-brand-gold">{bus.status === 'out_of_service' ? 'Stopped' : (bus.eta_en || '—')}</span></div>
                    </div>

                    <div className="mt-5 pt-5 border-t border-slate-200 dark:border-brand-purple-card/60">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-slate-900 dark:text-brand-text-secondary mb-2"><span>Occupancy</span><span>{occupancy}/{capacity} · {ratio}%</span></div>
                      <div className="h-3 rounded-full bg-white dark:bg-brand-purple-card overflow-hidden border border-slate-200 dark:border-brand-purple-card"><div className="h-full rounded-full bg-brand-gold" style={{ width: `${ratio}%` }} /></div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5 md:gap-8 mb-12">
          <div className="bg-white dark:bg-brand-purple-card rounded-[2rem] md:rounded-[2.5rem] border border-slate-200 dark:border-brand-purple-dark p-5 md:p-8 shadow-2xl shadow-slate-200/50 dark:shadow-none flex flex-col overflow-hidden">
            <div className="flex items-center justify-between mb-5 md:mb-8">
              <div className="flex items-center gap-4"><div className="bg-brand-gold/10 p-3 rounded-2xl"><Bus className="w-5 h-5 text-brand-gold" /></div><h3 className="font-extrabold text-slate-900 dark:text-white text-base md:text-lg tracking-tight uppercase">Service Maintenance</h3></div>
            </div>
            <div className="overflow-x-auto custom-scrollbar -mx-2 px-2">
              <table className="w-full text-left text-sm min-w-[760px]">
                <thead className="text-[10px] text-slate-950 dark:text-brand-text-secondary uppercase tracking-[0.2em] bg-slate-200 dark:bg-brand-purple-dark/30">
                  <tr><th className="px-6 py-5 font-black rounded-l-2xl">Plate ID</th><th className="px-6 py-5 font-black">Driver</th><th className="px-6 py-5 font-black">Receveur</th><th className="px-6 py-5 font-black">Maintenance</th><th className="px-6 py-5 font-black">Status</th><th className="px-6 py-5 font-black rounded-r-2xl text-right pr-10">Action</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-brand-purple-dark/50">
                  {buses.map(bus => {
                    const maintStatus = getMaintenanceStatus(bus.next_maintenance_date);
                    return (
                      <tr key={bus.id} className="hover:bg-slate-50 dark:hover:bg-brand-purple-dark/20 transition-all group">
                        <td className="px-6 py-6 font-extrabold text-slate-900 dark:text-white">{bus.plate_number}</td>
                        <td className="px-6 py-6 text-slate-900 dark:text-brand-text-secondary font-black">{bus.driver_name_en || '—'}</td>
                        <td className="px-6 py-6 text-slate-900 dark:text-brand-text-secondary font-black">{bus.receveur_name_en || '—'}</td>
                        <td className="px-6 py-6 text-slate-900 dark:text-brand-text-secondary font-black">{bus.next_maintenance_date ? new Date(bus.next_maintenance_date).toLocaleDateString() : '—'}<span className="block text-[10px] opacity-60 mt-1">{bus.maintenance_note || ''}</span></td>
                        <td className="px-6 py-6"><span className={`inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border-2 ${maintStatus.color}`}>{maintStatus.label}</span></td>
                        <td className="px-6 py-6 text-right pr-6"><button onClick={() => openEditBus(bus)} className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-brand-gold/30 text-brand-gold text-[10px] font-black uppercase tracking-widest hover:bg-brand-gold/10"><Pencil className="w-3 h-3" /> Edit</button></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white dark:bg-brand-purple-card rounded-[2rem] md:rounded-[2.5rem] border border-slate-200 dark:border-brand-purple-dark p-5 md:p-8 shadow-2xl shadow-slate-200/50 dark:shadow-none flex flex-col overflow-hidden">
            <div className="flex items-center gap-4 mb-5 md:mb-8"><div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-2xl"><AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" /></div><h3 className="font-extrabold text-slate-900 dark:text-white text-base md:text-lg tracking-tight uppercase">Safety Logs</h3></div>
            <div className="overflow-x-auto custom-scrollbar -mx-2 px-2">
              <table className="w-full text-left text-sm min-w-[500px]">
                <thead className="text-[10px] text-slate-950 dark:text-brand-text-secondary uppercase tracking-[0.2em] bg-slate-200 dark:bg-brand-purple-dark/30"><tr><th className="px-6 py-5 font-black rounded-l-2xl">Priority</th><th className="px-6 py-5 font-black">Unit ID</th><th className="px-6 py-5 font-black rounded-r-2xl">{t('description')}</th></tr></thead>
                <tbody className="divide-y divide-slate-100 dark:divide-brand-purple-dark/50">
                  {complaints.length === 0 ? <tr><td colSpan={3} className="text-center py-20 text-slate-900 font-black uppercase tracking-widest text-[11px] italic opacity-60">System Clear — No active reports.</td></tr> : complaints.slice(0, 5).map(c => (
                    <tr key={c.id} className="hover:bg-red-50/20 dark:hover:bg-red-900/10 transition-all group"><td className="px-6 py-6"><span className="inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black bg-white dark:bg-brand-purple-dark text-red-600 border border-red-200 dark:border-red-900/50 uppercase tracking-widest">{t(`categories.${c.category}`)}</span></td><td className="px-6 py-6 font-extrabold text-slate-900 dark:text-white uppercase">{c.bus_plate}</td><td className="px-6 py-6 text-slate-900 dark:text-brand-text-secondary max-w-xs truncate font-black">{c.description}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      {showBusEditor && (
        <div className="fixed inset-0 z-[20000] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto custom-scrollbar rounded-[2rem] bg-white dark:bg-brand-purple-card border border-brand-gold/30 p-6 md:p-8 shadow-2xl">
            <div className="flex items-start justify-between gap-4 mb-6">
              <div>
                <h3 className="text-xl md:text-2xl font-black text-slate-950 dark:text-white uppercase tracking-widest">{editingBus ? 'Edit bus information' : 'Add new bus'}</h3>
                <p className="text-xs font-black text-slate-500 dark:text-brand-text-secondary uppercase tracking-widest mt-2">Admin can update driver, receveur, route, maintenance and service status.</p>
              </div>
              <button onClick={() => setShowBusEditor(false)} className="p-3 rounded-2xl bg-slate-100 dark:bg-brand-purple-dark text-slate-900 dark:text-white"><X className="w-5 h-5" /></button>
            </div>

            {formError && <div className="mb-5 rounded-2xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/40 px-4 py-3 text-sm font-black text-red-700 dark:text-red-300">{formError}</div>}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Plate number<input className={inputClass} value={busForm.plate_number} onChange={e => handleBusFormChange('plate_number', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Status<select className={inputClass} value={busForm.status} onChange={e => handleBusFormChange('status', e.target.value)}><option value="working">working</option><option value="delayed">delayed</option><option value="out_of_service">out_of_service</option></select></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Driver<input className={inputClass} value={busForm.driver_name_en} onChange={e => handleBusFormChange('driver_name_en', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Receveur<input className={inputClass} value={busForm.receveur_name_en} onChange={e => handleBusFormChange('receveur_name_en', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">From<input className={inputClass} value={busForm.from_en} onChange={e => handleBusFormChange('from_en', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">To<input className={inputClass} value={busForm.to_en} onChange={e => handleBusFormChange('to_en', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">ETA<input className={inputClass} value={busForm.eta_en} onChange={e => handleBusFormChange('eta_en', e.target.value)} disabled={busForm.status === 'out_of_service'} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Capacity<input type="number" className={inputClass} value={busForm.capacity} onChange={e => handleBusFormChange('capacity', e.target.value)} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Passengers<input type="number" className={inputClass} value={busForm.status === 'out_of_service' ? 0 : busForm.passengers} onChange={e => handleBusFormChange('passengers', e.target.value)} disabled={busForm.status === 'out_of_service'} /></label>
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Next maintenance date<input type="date" className={inputClass} value={busForm.next_maintenance_date || ''} onChange={e => handleBusFormChange('next_maintenance_date', e.target.value)} /></label>
              <label className="md:col-span-2 text-[10px] font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Maintenance note<input className={inputClass} value={busForm.maintenance_note} onChange={e => handleBusFormChange('maintenance_note', e.target.value)} /></label>
            </div>

            <div className="flex justify-end gap-3 mt-8">
              <button onClick={() => setShowBusEditor(false)} className="px-5 py-3 rounded-2xl border border-slate-200 dark:border-brand-purple-dark text-sm font-black uppercase tracking-widest text-slate-700 dark:text-brand-text-secondary">Cancel</button>
              <button onClick={saveBus} className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-brand-gold text-brand-purple-dark text-sm font-black uppercase tracking-widest"><Save className="w-4 h-4" /> Save changes</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
