import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { MapView as MapComponent } from '../components/MapView';
import { TopBar } from '../components/shared/TopBar';
import { ComplaintForm } from '../components/ComplaintForm';
import { io } from 'socket.io-client';
import { Bus, MapPin, Clock, AlertTriangle, LogOut, Navigation } from 'lucide-react';

export const UserDashboardPage: React.FC = () => {
  const { user, logout, token } = useAuth();
  const { t, language } = useLanguage();
  const [buses, setBuses] = useState<any[]>([]);
  const [stops, setStops] = useState<any[]>([]);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [nearestStop, setNearestStop] = useState<any>(null);
  const [showComplaintForm, setShowComplaintForm] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  useEffect(() => {
    fetch('/api/buses/stops').then(res => res.json()).then(data => {
      if (Array.isArray(data)) setStops(data);
    });

    const socket = io();
    socket.on('bus_positions', (data) => setBuses(data));

    let watchId: number | null = null;

    if ("geolocation" in navigator) {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          setUserLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        (err) => {
          console.warn("Geolocation error:", err.message);
          setUserLocation(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0,
        }
      );
    }

    return () => {
      socket.disconnect();
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  useEffect(() => {
    if (userLocation && stops.length > 0) {
      const distanceKm = (aLat: number, aLng: number, bLat: number, bLng: number) => {
        const R = 6371;
        const dLat = ((bLat - aLat) * Math.PI) / 180;
        const dLng = ((bLng - aLng) * Math.PI) / 180;
        const x =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((aLat * Math.PI) / 180) *
          Math.cos((bLat * Math.PI) / 180) *
          Math.sin(dLng / 2) ** 2;
        return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
      };

      let nearest = stops[0];
      let minDist = Infinity;
      stops.forEach(stop => {
        const dist = distanceKm(userLocation.lat, userLocation.lng, stop.latitude, stop.longitude);
        if (dist < minDist) {
          minDist = dist;
          nearest = stop;
        }
      });
      setNearestStop(nearest);
    }
  }, [userLocation, stops]);

  const nearestBus = buses.length > 0 ? [...buses].sort((a,b) => a.eta_minutes - b.eta_minutes)[0] : null;

  const submitComplaint = async (form: any) => {
    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(form)
      });
      if (res.ok) {
        setShowComplaintForm(false);
        alert('Report submitted successfully.');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen md:h-screen w-full flex flex-col md:flex-row bg-transparent transition-colors duration-300 md:overflow-hidden">
      
      <TopBar onMenuClick={() => setShowMobileSidebar(true)} />

      {/* Sidebar - Passenger View */}
      <aside className={`fixed inset-y-0 left-0 z-[10000] w-[86vw] max-w-80 bg-white dark:bg-brand-purple-card border-r border-slate-200 dark:border-brand-purple-card/50 flex flex-col shadow-xl transition-transform duration-500 ease-in-out md:relative md:translate-x-0 ${showMobileSidebar ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 md:p-8 border-b border-slate-200 dark:border-brand-purple-card flex flex-col items-center gap-4 bg-gradient-to-br from-white to-brand-purple-light dark:from-brand-purple-card dark:to-brand-purple-dark/50">
          <div className="flex items-center justify-center">
            <img src="/logo.png" alt="STM Logo" className="w-32 h-32 md:w-36 md:h-36 object-contain drop-shadow-[0_14px_28px_rgba(31,18,51,0.35)] dark:drop-shadow-[0_14px_28px_rgba(212,175,55,0.28)]" onError={(e) => (e.currentTarget.style.display = 'none')} />
            <Bus className="w-10 h-10 text-brand-gold hidden" />
          </div>
          <div className="text-center">
            <h1 className="stm-title-decorative stm-title-sidebar">
              Saida Transit Monitor (STM)
            </h1>
            <p className="text-[10px] font-black text-brand-gold-soft dark:text-brand-gold uppercase tracking-widest mt-1.5 opacity-90">Passenger Services</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
          {/* Nearest Stop Info */}
          <section>
            <p className="text-[10px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-[0.25em] mb-6 flex items-center gap-3">
              <span className="w-8 h-[2px] bg-slate-400 dark:bg-brand-purple-card rounded-full"></span>
              {t('nearest_stop')}
            </p>
            <div className="bg-white dark:bg-brand-purple-dark p-5 rounded-2xl border border-slate-200 dark:border-brand-purple-card/50 shadow-sm hover:shadow-md transition-all duration-300">
              {nearestStop ? (
                <div className="flex items-center gap-4">
                  <div className="bg-brand-purple-light dark:bg-brand-gold/10 p-3 rounded-xl border border-brand-purple-light dark:border-brand-gold/20">
                    <MapPin className="w-6 h-6 text-brand-gold" />
                  </div>
                  <div>
                    <p className="font-extrabold text-slate-900 dark:text-white text-base leading-tight mb-1">{nearestStop['name_' + language] || nearestStop.name_en || nearestStop.name_fr || nearestStop.name || 'Station'}</p>
                    <div className="text-[11px] text-slate-900 dark:text-brand-text-secondary font-black uppercase tracking-wider flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                      Nearby
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-slate-900 font-black italic">Locating nearest stop...</p>
              )}
            </div>
          </section>

          {/* Nearest Bus Info */}
          <section>
            <p className="text-[10px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-[0.25em] mb-6 flex items-center gap-3">
              <span className="w-8 h-[2px] bg-slate-400 dark:bg-brand-purple-card rounded-full"></span>
              Next Arrival
            </p>
            <div className="bg-white dark:bg-brand-purple-dark p-5 rounded-2xl border border-slate-200 dark:border-brand-purple-card/50 shadow-sm hover:shadow-md transition-all duration-300">
              {nearestBus ? (
                <div className="flex items-center gap-4">
                  <div className="bg-brand-gold/10 p-3 rounded-xl border border-brand-gold/30">
                    <Bus className="w-6 h-6 text-brand-gold" />
                  </div>
                  <div>
                    <p className="font-extrabold text-slate-900 dark:text-white text-base leading-tight mb-1">{nearestBus.plate_number}</p>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-brand-gold" />
                      <span className="text-xs font-black text-brand-gold uppercase tracking-wider">{nearestBus.eta_minutes} mins</span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-slate-900 font-black italic">Scanning fleet...</p>
              )}
            </div>
          </section>

          <button 
            onClick={() => setShowComplaintForm(true)}
            className="group w-full bg-red-600 hover:bg-red-700 text-white p-5 rounded-2xl shadow-xl shadow-red-600/20 transition-all flex items-center justify-center gap-4 font-black uppercase tracking-widest text-xs active:scale-[0.98]"
          >
            <AlertTriangle className="w-5 h-5 group-hover:animate-bounce" />
            <span>{t('report_issue')}</span>
          </button>
        </div>

        <div className="p-6 border-t border-slate-200 dark:border-brand-purple-dark bg-slate-200 dark:bg-brand-purple-dark/50">
          <button
            onClick={logout}
            className="flex items-center justify-center gap-3 w-full p-4 bg-white dark:bg-brand-purple-dark text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-brand-purple-card border border-slate-200 dark:border-brand-purple-card rounded-2xl transition-all shadow-sm font-extrabold text-xs uppercase tracking-widest active:scale-[0.98]"
          >
            <LogOut className="w-5 h-5" />
            <span>{t('logout')}</span>
          </button>
        </div>
      </aside>

      {/* Main Map View */}
      <main className="flex-1 relative h-[100svh] min-h-[560px] md:h-full w-full">
        <MapComponent buses={buses} stops={stops} userLocation={userLocation} isAdmin={false} />
      </main>

      {/* Mobile Overlay */}
      {showMobileSidebar && (
        <div 
          className="fixed inset-0 bg-brand-purple-dark/60 backdrop-blur-sm z-[9998] md:hidden"
          onClick={() => setShowMobileSidebar(false)}
        ></div>
      )}

      {/* Complaint Modal */}
      {showComplaintForm && (
        <ComplaintForm 
          onClose={() => setShowComplaintForm(false)} 
          onSubmit={submitComplaint} 
          buses={buses} 
          stops={stops} 
        />
      )}
    </div>
  );
};
