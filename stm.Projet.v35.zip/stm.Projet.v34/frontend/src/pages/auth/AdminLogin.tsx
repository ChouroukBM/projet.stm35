import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { Mail, Lock, Eye, EyeOff, ArrowLeft, AlertTriangle } from 'lucide-react';
import { TopBar } from '../../components/shared/TopBar';

export const AdminLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      login(data.token, data.user);
      navigate('/admin');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-transparent flex items-center justify-center p-6 transition-colors duration-300 relative overflow-hidden">
      <TopBar />
      
      {/* High-Security Aesthetic Decorative Elements */}
      <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] bg-brand-gold/10 dark:bg-brand-gold/5 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-brand-purple-card/10 dark:bg-brand-purple-card/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="bg-white/90 dark:bg-brand-purple-card/90 backdrop-blur-2xl p-10 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.4)] w-full max-w-md border border-white dark:border-brand-purple-card z-10 relative">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-brand-gold via-brand-gold-soft to-brand-gold rounded-t-[2.5rem]"></div>
        
        <div className="flex flex-col items-center mb-10">
          <div className="h-32 w-32 rounded-[2.25rem] bg-white/85 dark:bg-brand-purple-dark/80 p-3 mb-7 shadow-xl border border-brand-gold/20 overflow-hidden">
            <img src="/logo.png" alt="Saida Transit Monitor (STM)" className="h-full w-full object-contain" />
          </div>
          <h1 className="text-4xl font-black text-center tracking-[0.08em] leading-tight bg-gradient-to-r from-brand-purple-dark via-brand-gold-soft to-brand-gold dark:from-white dark:via-brand-gold-soft dark:to-brand-gold bg-clip-text text-transparent drop-shadow-sm uppercase">
            Saida Transit Monitor <span className="text-brand-gold">(STM)</span>
          </h1>
          <p className="text-brand-gold-soft/70 dark:text-brand-gold/70 font-black text-xs mt-3 uppercase tracking-[0.25em]">{t('admin_portal')}</p>
        </div>

        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 p-4 rounded-2xl mb-8 text-sm font-bold flex items-center gap-3 animate-shake">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[11px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-widest mb-2.5 ml-1">{t('email')}</label>
            <div className="relative group">
              <Mail className="absolute left-4 rtl:right-4 rtl:left-auto top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-gold transition-colors" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white dark:bg-brand-purple-dark border border-brand-purple-light dark:border-brand-purple-card rounded-2xl py-4 pl-12 rtl:pr-12 rtl:pl-4 pr-4 text-slate-900 dark:text-white font-medium placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-brand-gold/10 focus:border-brand-gold transition-all shadow-sm"
                required
                placeholder="admin@stm.dz"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-widest mb-2.5 ml-1">{t('password')}</label>
            <div className="relative group">
              <Lock className="absolute left-4 rtl:right-4 rtl:left-auto top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-gold transition-colors" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white dark:bg-brand-purple-dark border border-brand-purple-light dark:border-brand-purple-card rounded-2xl py-4 pl-12 rtl:pr-12 rtl:pl-12 pr-12 text-slate-900 dark:text-white font-medium placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-brand-gold/10 focus:border-brand-gold transition-all shadow-sm"
                required
                placeholder="••••••••"
              />
              <button 
                type="button" 
                onClick={() => setShowPassword(!showPassword)} 
                className="absolute right-4 rtl:left-4 rtl:right-auto top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-brand-gold hover:bg-brand-gold-soft text-brand-purple-dark font-extrabold py-4 rounded-2xl transition-all shadow-lg shadow-brand-gold/20 hover:shadow-brand-gold/40 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] mt-2 tracking-wide uppercase text-sm"
          >
            {t('sign_in')}
          </button>
        </form>
        
        <div className="mt-10 pt-8 border-t border-slate-100 dark:border-brand-purple-card text-center">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-slate-950 hover:text-slate-700 dark:hover:text-brand-text-secondary font-black transition-all group">
            <ArrowLeft className="w-4 h-4 rtl:rotate-180 group-hover:-translate-x-1 transition-transform" /> Return to Gateway
          </Link>
        </div>
      </div>
    </div>
  );
};
