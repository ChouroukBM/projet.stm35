import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { TopBar } from '../components/shared/TopBar';
import { Bus, ShieldAlert } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-brand-purple-light dark:bg-brand-purple-dark flex flex-col items-center justify-start sm:justify-center px-4 py-24 sm:py-10 transition-colors duration-300 relative overflow-hidden text-slate-950 dark:text-white">
      <TopBar />
      <div className="absolute top-[-20%] left-[-10%] w-[700px] h-[700px] bg-brand-gold/15 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[700px] h-[700px] bg-brand-purple-card/20 dark:bg-brand-gold/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="z-10 text-center mb-8 sm:mb-12 mt-10 sm:mt-16 max-w-4xl">
        <div className="mx-auto mb-8 flex items-center justify-center">
          <img src="/logo.png" alt="Saida Transit Monitor (STM)" className="h-32 w-32 sm:h-44 sm:w-44 md:h-60 md:w-60 object-contain drop-shadow-[0_20px_45px_rgba(31,18,51,0.32)] dark:drop-shadow-[0_20px_45px_rgba(212,175,55,0.25)]" />
        </div>
        <h1 className="stm-title-decorative stm-title-hero mb-4 sm:mb-6">
          Saida Transit Monitor (STM)
        </h1>
        <p className="text-xs sm:text-base md:text-xl text-slate-700 dark:text-brand-text-secondary max-w-3xl mx-auto font-extrabold uppercase tracking-widest leading-relaxed">
          The future of public transit tracking in Saida.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 w-full max-w-6xl z-10 px-1 sm:px-4">
        <Link to="/login" className="group relative bg-white/85 dark:bg-brand-purple-card/80 backdrop-blur-xl rounded-[2rem] sm:rounded-[2.5rem] p-6 sm:p-10 shadow-2xl transition-all duration-500 border border-white dark:border-brand-purple-card/40 overflow-hidden flex flex-col items-center text-center hover:-translate-y-2">
          <div className="relative z-10 bg-brand-gold/10 p-5 sm:p-7 rounded-[1.5rem] sm:rounded-[2rem] mb-5 sm:mb-8 text-brand-gold group-hover:scale-105 transition-all duration-500 shadow-inner">
            <Bus className="w-9 h-9 sm:w-12 sm:h-12" />
          </div>
          <h2 className="relative z-10 text-2xl sm:text-3xl md:text-4xl font-black text-slate-950 dark:text-white mb-5 uppercase tracking-tight">{t('passenger_portal')}</h2>
          <p className="relative z-10 text-slate-700 dark:text-brand-text-secondary text-base md:text-lg leading-relaxed font-bold">Track buses live, find stops nearby, and contribute to a better commute.</p>
          <div className="relative z-10 mt-6 sm:mt-9 flex items-center text-brand-gold-soft dark:text-brand-gold font-black uppercase tracking-[0.18em] gap-4">
            Enter Portal <span className="text-2xl mt-[-4px] rtl:rotate-180">→</span>
          </div>
        </Link>

        <Link to="/admin-login" className="group relative bg-white/85 dark:bg-brand-purple-card/80 backdrop-blur-xl rounded-[2rem] sm:rounded-[2.5rem] p-6 sm:p-10 shadow-2xl transition-all duration-500 border border-white dark:border-brand-purple-card/40 overflow-hidden flex flex-col items-center text-center hover:-translate-y-2">
          <div className="relative z-10 bg-brand-gold/10 p-5 sm:p-7 rounded-[1.5rem] sm:rounded-[2rem] mb-5 sm:mb-8 text-brand-gold group-hover:scale-105 transition-all duration-500 shadow-inner">
            <ShieldAlert className="w-9 h-9 sm:w-12 sm:h-12" />
          </div>
          <h2 className="relative z-10 text-2xl sm:text-3xl md:text-4xl font-black text-slate-950 dark:text-white mb-5 uppercase tracking-tight">{t('admin_portal')}</h2>
          <p className="relative z-10 text-slate-700 dark:text-brand-text-secondary text-base md:text-lg leading-relaxed font-bold">Manage the entire Saida transit fleet with real-time supervision tools.</p>
          <div className="relative z-10 mt-6 sm:mt-9 flex items-center text-brand-gold-soft dark:text-brand-gold font-black uppercase tracking-[0.18em] gap-4">
            Secure Login <span className="text-2xl mt-[-4px] rtl:rotate-180">→</span>
          </div>
        </Link>
      </div>
    </div>
  );
};
