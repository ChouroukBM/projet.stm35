import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ThemeProvider } from "./context/ThemeContext";
import { LanguageProvider } from "./context/LanguageContext";

import { LandingPage } from "./pages/LandingPage";
import { UserLogin } from "./pages/auth/UserLogin";
import { AdminLogin } from "./pages/auth/AdminLogin";
import { Register } from "./pages/auth/Register";
import { ForgotPassword } from "./pages/auth/ForgotPassword";
import { UserDashboardPage } from "./pages/UserDashboardPage";
import { AdminDashboardPage } from "./pages/AdminDashboardPage";

const ProtectedRoute = ({ children, allowedRole }: { children: React.ReactNode, allowedRole: 'user' | 'admin' }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to={allowedRole === 'admin' ? '/admin-login' : '/login'} />;
  if (user.role !== allowedRole) return <Navigate to={user.role === 'admin' ? '/admin' : '/user'} />;
  return <>{children}</>;
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={user ? <Navigate to={user.role === 'admin' ? '/admin' : '/user'} /> : <LandingPage />} />
      <Route path="/login" element={user ? <Navigate to="/user" /> : <UserLogin />} />
      <Route path="/admin-login" element={user ? <Navigate to="/admin" /> : <AdminLogin />} />
      <Route path="/register" element={user ? <Navigate to="/user" /> : <Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />

      {/* Protected Routes */}
      <Route path="/user/*" element={<ProtectedRoute allowedRole="user"><UserDashboardPage /></ProtectedRoute>} />
      <Route path="/admin/*" element={<ProtectedRoute allowedRole="admin"><AdminDashboardPage /></ProtectedRoute>} />
    </Routes>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <BrowserRouter>
            <AppRoutes />
          </BrowserRouter>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
