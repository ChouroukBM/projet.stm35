import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { useLanguage } from '../../context/LanguageContext';
import { Moon, Sun, Globe, Menu } from 'lucide-react';

interface TopBarProps {
  onMenuClick?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onMenuClick }) => {
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage } = useLanguage();

  return (
    <>
      {!onMenuClick && (
        <div className="absolute top-3 left-3 rtl:right-3 rtl:left-auto z-[9999] flex items-center gap-2 sm:gap-4 bg-white/75 dark:bg-brand-purple-card/75 backdrop-blur-md rounded-2xl sm:rounded-3xl px-3 sm:px-5 py-2 sm:py-3 border border-white/70 dark:border-brand-gold/20 shadow-xl shadow-brand-gold/5 transition-all hover:scale-[1.02]">
          <img src="/logo.png" alt="Saida Transit Monitor (STM) Logo" className="w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 object-contain drop-shadow-[0_8px_18px_rgba(31,18,51,0.35)] dark:drop-shadow-[0_8px_20px_rgba(212,175,55,0.28)]" onError={(e) => (e.currentTarget.style.display = 'none')} />
          <span className="stm-title-decorative stm-title-small hidden sm:block">Saida Transit Monitor (STM)</span>
        </div>
      )}

      <div className="fixed top-3 right-3 rtl:left-3 rtl:right-auto z-[10002] flex gap-2 sm:gap-4">
      {onMenuClick && (
        <button 
          onClick={onMenuClick}
          className="p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-brand-purple-card backdrop-blur-md shadow-lg text-slate-900 dark:text-white md:hidden border border-white dark:border-brand-purple-dark active:scale-95 transition-all"
        >
          <Menu className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      )}
      
      <div className="relative group">
        <button className="p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-brand-purple-card backdrop-blur-md shadow-lg text-slate-900 dark:text-brand-text-secondary hover:text-brand-gold dark:hover:text-brand-gold hover:border-brand-gold/30 dark:hover:border-brand-gold/30 transition-all duration-300 border border-slate-200 dark:border-brand-purple-dark">
          <Globe className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
        <div className="absolute right-0 rtl:left-0 rtl:right-auto mt-3 w-44 bg-white dark:bg-brand-purple-dark backdrop-blur-xl rounded-2xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 border border-slate-200 dark:border-brand-purple-dark overflow-hidden py-2 scale-95 group-hover:scale-100 origin-top-right">
          <button onClick={() => setLanguage('en')} className={`block w-full text-start px-5 py-3 text-sm hover:bg-brand-purple-light dark:hover:bg-brand-purple-card/50 transition-colors ${language === 'en' ? 'font-bold text-brand-gold dark:text-brand-gold bg-brand-purple-light dark:bg-brand-gold/20' : 'text-slate-900 dark:text-brand-text-secondary font-black'}`}>English</button>
          <button onClick={() => setLanguage('fr')} className={`block w-full text-start px-5 py-3 text-sm hover:bg-brand-purple-light dark:hover:bg-brand-purple-card/50 transition-colors ${language === 'fr' ? 'font-bold text-brand-gold dark:text-brand-gold bg-brand-purple-light dark:bg-brand-gold/20' : 'text-slate-900 dark:text-brand-text-secondary font-black'}`}>Français</button>
          <button onClick={() => setLanguage('ar')} className={`block w-full text-start px-5 py-3 text-sm hover:bg-brand-purple-light dark:hover:bg-brand-purple-card/50 transition-colors ${language === 'ar' ? 'font-bold text-brand-gold dark:text-brand-gold bg-brand-purple-light dark:bg-brand-gold/20' : 'text-slate-900 dark:text-brand-text-secondary font-black'}`}>العربية</button>
        </div>
      </div>

      <button onClick={toggleTheme} className="p-3 sm:p-3.5 rounded-2xl bg-white dark:bg-brand-purple-card backdrop-blur-md shadow-lg text-slate-900 dark:text-brand-text-secondary hover:text-brand-gold dark:hover:text-brand-gold hover:border-brand-gold/30 dark:hover:border-brand-gold/30 transition-all duration-300 border border-slate-200 dark:border-brand-purple-dark">
        {theme === 'dark' ? <Sun className="w-4 h-4 sm:w-5 sm:h-5" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5" />}
      </button>
    </div>
    </>
  );
};
