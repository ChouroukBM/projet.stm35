import React, { useState } from 'react';
import { AlertTriangle, X, ArrowRight } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

interface ComplaintFormProps {
  onClose: () => void;
  onSubmit: (form: any) => Promise<void>;
  buses: any[];
  stops: any[];
}

export const ComplaintForm: React.FC<ComplaintFormProps> = ({ onClose, onSubmit, buses, stops }) => {
  const { t } = useLanguage();
  const [form, setForm] = useState({ 
    bus_id: '', 
    stop_id: '', 
    category: 'delay', 
    bus_type: 'standard', 
    description: '' 
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(form);
  };

  return (
    <div className="fixed inset-0 z-[10002] flex items-center justify-center p-4 md:p-6 transition-all duration-500 animate-in fade-in">
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
        onClick={onClose}
      ></div>
      
      <div className="bg-white dark:bg-brand-purple-card w-full max-w-xl rounded-[2.5rem] shadow-[0_30px_60px_rgba(0,0,0,0.2)] dark:shadow-[0_30px_60px_rgba(0,0,0,0.5)] border border-white dark:border-brand-purple-dark p-8 md:p-12 relative z-10 scale-in-center overflow-hidden">
        
        {/* Professional Header */}
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-5">
            <div className="bg-red-50 dark:bg-red-500/10 p-4 rounded-3xl border border-red-100 dark:border-red-900/30">
              <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
            </div>
            <div>
              <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight uppercase">{t('report_issue')}</h2>
              <p className="text-[10px] font-black text-slate-700 dark:text-brand-text-secondary uppercase tracking-widest mt-1">Safety & Operations Log</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-3 bg-slate-50 dark:bg-brand-purple-dark/50 rounded-2xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-all border border-slate-100 dark:border-brand-purple-dark"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Category Selection */}
            <div>
              <label className="block text-[11px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-widest mb-3 ml-1">{t('category')}</label>
              <div className="relative group">
                <select
                  value={form.category}
                  onChange={(e) => setForm({...form, category: e.target.value})}
                  className="w-full bg-slate-50 dark:bg-brand-purple-dark border border-slate-200 dark:border-brand-purple-dark rounded-2xl py-4 px-5 text-slate-900 dark:text-white font-extrabold text-sm appearance-none focus:outline-none focus:ring-4 focus:ring-brand-gold/10 focus:border-brand-gold transition-all cursor-pointer shadow-sm"
                >
                  <option value="delay">{t('categories.delay')}</option>
                  <option value="overcrowding">{t('categories.overcrowding')}</option>
                  <option value="driver_behavior">{t('categories.driver_behavior')}</option>
                  <option value="technical">{t('categories.technical')}</option>
                  <option value="route">{t('categories.route')}</option>
                  <option value="station">{t('categories.station')}</option>
                  <option value="eta_issue">{t('categories.eta_issue')}</option>
                  <option value="other">{t('categories.other')}</option>
                </select>
                <div className="absolute right-5 rtl:left-5 rtl:right-auto top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <ArrowRight className="w-4 h-4 rotate-90" />
                </div>
              </div>
            </div>

            {/* Bus Selection */}
            <div>
              <label className="block text-[11px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-widest mb-3 ml-1">Fleet Unit</label>
              <div className="relative group">
                <select
                  value={form.bus_id}
                  onChange={(e) => setForm({...form, bus_id: e.target.value})}
                  className="w-full bg-slate-50 dark:bg-brand-purple-dark border border-slate-200 dark:border-brand-purple-dark rounded-2xl py-4 px-5 text-slate-900 dark:text-white font-extrabold text-sm appearance-none focus:outline-none focus:ring-4 focus:ring-brand-gold/10 focus:border-brand-gold transition-all cursor-pointer shadow-sm"
                  required
                >
                  <option value="">Select a Bus</option>
                  {buses.map(b => (
                    <option key={b.id} value={b.id}>{b.plate_number} - {b.route_name}</option>
                  ))}
                </select>
                <div className="absolute right-5 rtl:left-5 rtl:right-auto top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                  <ArrowRight className="w-4 h-4 rotate-90" />
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-[11px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-widest mb-3 ml-1">{t('description')}</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({...form, description: e.target.value})}
              className="w-full bg-slate-50 dark:bg-brand-purple-dark border border-slate-200 dark:border-brand-purple-dark rounded-3xl py-5 px-6 text-slate-900 dark:text-white font-medium placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-brand-gold/10 focus:border-brand-gold transition-all min-h-[150px] shadow-sm resize-none"
              required
              placeholder="Provide detailed information about the incident..."
            />
          </div>

          <div className="flex flex-col md:flex-row gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 order-2 md:order-1 px-8 py-4 text-slate-700 dark:text-brand-text-secondary font-extrabold text-[10px] uppercase tracking-widest hover:text-slate-900 dark:hover:text-white transition-all underline decoration-slate-300 dark:decoration-brand-purple-dark underline-offset-4"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-[2] order-1 md:order-2 bg-red-600 hover:bg-brand-gold text-white hover:text-brand-purple-dark font-black py-5 rounded-[1.5rem] transition-all shadow-xl shadow-red-600/20 hover:shadow-brand-gold/20 active:scale-[0.98] uppercase tracking-[0.2em] text-[10px] flex items-center justify-center gap-4"
            >
              Verify & Submit Logs
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
