import React, { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Layers } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { stopsData } from "@/data/stopsData";
import { routesData } from "@/data/routesData";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const busIcon = new L.DivIcon({
  className: "custom-bus-icon",
  html: `<div class="stm-bus-marker">
    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11V4h16v7"/><path d="M4 11h16v8H4z"/><circle cx="7" cy="19" r="2"/><circle cx="17" cy="19" r="2"/><path d="M8 11V7"/><path d="M16 11V7"/><path d="M2 13h2"/><path d="M20 13h2"/></svg>
  </div>`,
  iconSize: [36, 36],
  iconAnchor: [18, 18],
  popupAnchor: [0, -18],
});

const stopIcon = new L.DivIcon({
  className: "custom-stop-icon",
  html: `<div class="stm-stop-marker">
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
  </div>`,
  iconSize: [34, 34],
  iconAnchor: [17, 17],
  popupAnchor: [0, -17],
});

const hubIcon = new L.DivIcon({
  className: "custom-hub-icon",
  html: `<div class="stm-hub-marker">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
  </div>`,
  iconSize: [42, 42],
  iconAnchor: [21, 21],
  popupAnchor: [0, -21],
});

const userIcon = new L.Icon({
  iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

interface MapProps {
  buses: any[];
  stops: any[];
  userLocation?: { lat: number; lng: number } | null;
  isAdmin?: boolean;
}

const routeColors: Record<string, string> = {
  "Bus 07": "#3b5bdb",
  "Bus 13": "#d9480f",
  "Bus 16": "#2f9e44",
  "Bus 02": "#b8860b",
  "Bus 08": "#7c3aed",
  "Bus 09": "#c2255c",
  "Bus 10": "#0ea5e9",
};

const FitToStations: React.FC = () => {
  const map = useMap();
  useEffect(() => {
    const bounds = L.latLngBounds(stopsData.map(s => [s.latitude, s.longitude] as [number, number]));
    map.fitBounds(bounds, { padding: [35, 35], maxZoom: 14 });
  }, [map]);
  return null;
};

const FollowUserLocation: React.FC<{ userLocation?: { lat: number; lng: number } | null }> = ({ userLocation }) => {
  const map = useMap();
  useEffect(() => {
    if (userLocation) {
      map.flyTo([userLocation.lat, userLocation.lng], Math.max(map.getZoom(), 15), {
        animate: true,
        duration: 0.8,
      });
    }
  }, [map, userLocation?.lat, userLocation?.lng]);
  return null;
};

export const MapView: React.FC<MapProps> = ({ buses, userLocation, isAdmin }) => {
  const { language } = useLanguage();
  const [isSatellite, setIsSatellite] = useState(false);

  const stationById = useMemo(() => new Map(stopsData.map(s => [s.id_str, s])), []);

  const getLocalized = (obj: any, baseKey: string) => {
    return obj[`${baseKey}_${language}`] || obj[`${baseKey}_en`] || obj[baseKey] || "";
  };

  const getTileUrl = () => {
    if (isSatellite) {
      return "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
    }
    // Keep the map simple and readable in both themes.
    // Theme colors affect the UI only, not the map tiles.
    return "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
  };

  const getRouteStopNames = (bus: any) => {
    try {
      const list = JSON.parse(bus.stops_list || "[]");
      return list.map((s: any) => getLocalized(s, "name")).filter(Boolean);
    } catch {
      return [];
    }
  };

  return (
    <div className="h-full w-full z-0 relative">
      <div className="absolute bottom-6 right-3 z-[1000] flex flex-col gap-2">
        <button
          onClick={() => setIsSatellite(!isSatellite)}
          className={`p-2.5 rounded-xl shadow-xl backdrop-blur-md border-2 transition-all duration-300 flex items-center justify-center gap-2 ${
            isSatellite
              ? "bg-amber-600 border-amber-400 text-white"
              : "bg-white/90 border-slate-200 text-slate-800 hover:bg-amber-50"
          }`}
          title={isSatellite ? "Standard map" : "Satellite map"}
        >
          <Layers className="w-5 h-5" />
        </button>
      </div>

      <MapContainer center={[34.839, 0.154]} zoom={13} className="h-full w-full" zoomControl={true}>
        <FitToStations />
        <FollowUserLocation userLocation={userLocation} />
        <TileLayer
          url={getTileUrl()}
          attribution={isSatellite ? 'Tiles &copy; Esri' : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}
        />

        {routesData.map(route => {
          const positions = route.stops
            .map(id => stationById.get(id))
            .filter(Boolean)
            .map(st => [st!.latitude, st!.longitude] as [number, number]);
          return (
            <Polyline
              key={route.id}
              positions={positions}
              pathOptions={{ color: routeColors[route.bus] || "#3b5bdb", weight: route.bus === "Bus 07" || route.bus === "Bus 13" ? 5 : 3.5, opacity: route.bus === "Bus 07" || route.bus === "Bus 13" ? 0.9 : 0.55, lineCap: "round", lineJoin: "round" }}
            />
          );
        })}

        {stopsData.map(station => (
          <Marker key={station.id_str} position={[station.latitude, station.longitude]} icon={station.id === 15 ? hubIcon : stopIcon}>
            <Popup>
              <div className="stm-popup-card min-w-[190px]">
                <div className="stm-popup-title">
                  <span className="stm-popup-number">#{station.id}</span> {getLocalized(station, "name")}
                </div>
                <div className="stm-popup-subtitle">Transit station</div>
                <div className="stm-popup-label">Buses</div>
                <div className="stm-popup-badges">
                  {station.buses.map(bus => <span key={bus} className="stm-popup-badge">Bus {bus}</span>)}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

        {buses.map(bus => {
          const stopNames = getRouteStopNames(bus);
          return (
            <Marker key={`bus-${bus.id}`} position={[bus.lat, bus.lng]} icon={busIcon}>
              <Popup>
                <div className="stm-popup-card min-w-[220px]">
                  <div className="stm-popup-title">{bus.plate_number}</div>
                  <div className="stm-popup-subtitle">{getLocalized(bus, "from")} → {getLocalized(bus, "to")}</div>
                  <div className="stm-popup-row"><strong>Driver:</strong> {getLocalized(bus, "driver_name")}</div>
                  <div className="stm-popup-row"><strong>ETA:</strong> {getLocalized(bus, "eta")}</div>
                  <div className="stm-popup-row"><strong>Capacity:</strong> {bus.occupancy ?? bus.passengers}/{bus.capacity}</div>
                  <div className="stm-popup-label">Route stops</div>
                  <ol className="stm-popup-list">
                    {stopNames.map((name: string, idx: number) => <li key={`${bus.id}-${idx}`}>{name}</li>)}
                  </ol>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {userLocation && !isAdmin && (
          <Marker position={[userLocation.lat, userLocation.lng]} icon={userIcon}>
            <Popup>Your real-time location</Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
};
