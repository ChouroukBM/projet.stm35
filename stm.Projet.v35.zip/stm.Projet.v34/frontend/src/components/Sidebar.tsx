import React from 'react';
import { ShieldAlert, Users, AlertTriangle, LogOut } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface SidebarProps {
  showSidebar: boolean;
  buses: any[];
  alerts: any[];
  logout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ showSidebar, buses, alerts, logout }) => {
  const { t } = useLanguage();

  return (
    <aside className={`fixed inset-y-0 left-0 z-[10001] w-[86vw] max-w-80 bg-white dark:bg-brand-purple-card flex flex-col shadow-xl transition-transform duration-500 ease-in-out md:relative md:translate-x-0 ${showSidebar ? 'translate-x-0' : '-translate-x-full'} border-r border-slate-200 dark:border-brand-purple-dark`}>
      <div className="p-6 md:p-8 border-b border-slate-200 dark:border-brand-purple-dark flex flex-col items-center gap-5 bg-gradient-to-br from-white to-brand-purple-light dark:from-brand-purple-card dark:to-brand-purple-dark/50">
        <div className="flex items-center justify-center">
          <img src="/logo.png" alt="STM Logo" className="w-36 h-36 md:w-40 md:h-40 object-contain drop-shadow-[0_14px_28px_rgba(31,18,51,0.35)] dark:drop-shadow-[0_14px_28px_rgba(212,175,55,0.28)]" onError={(e) => (e.currentTarget.style.display = 'none')} />
          <ShieldAlert className="w-10 h-10 text-brand-gold hidden" />
        </div>
        <div className="text-center">
          <h1 className="stm-title-decorative stm-title-sidebar">Saida Transit Monitor (STM)</h1>
          <p className="text-[10px] font-black text-brand-gold-soft dark:text-brand-gold uppercase tracking-widest mt-1.5 opacity-90">System Administration</p>
        </div>
      </div>
      
      <div className="p-4 md:p-6 flex-1 overflow-y-auto space-y-10 custom-scrollbar">
        <section>
          <p className="text-[10px] font-black text-slate-950 dark:text-brand-text-secondary uppercase tracking-[0.25em] mb-6 flex items-center gap-3">
            <span className="w-8 h-[2px] bg-slate-400 dark:bg-brand-purple-card rounded-full"></span>
            Active Fleet
          </p>
          <div className="space-y-4">
            {buses.map(bus => (
              <div key={bus.id} className="group bg-white dark:bg-brand-purple-dark p-5 rounded-2xl border border-slate-200 dark:border-brand-purple-card/50 shadow-sm hover:shadow-md hover:border-brand-gold/30 transition-all duration-300">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-extrabold text-slate-900 dark:text-white uppercase tracking-tight text-sm">{bus.plate_number}</span>
                  <span className={`text-[10px] px-3 py-1 rounded-full font-black uppercase tracking-wider border ${bus.fuel < 20 ? 'bg-red-50 text-red-600 border-red-100 dark:bg-red-900/20 dark:text-red-400 dark:border-red-900/30' : 'bg-brand-gold/10 text-brand-gold border-brand-gold/20 dark:bg-brand-gold/20 dark:text-brand-gold-soft dark:border-brand-gold/30'}`}>
                    {typeof bus.fuel === 'number' ? bus.fuel.toFixed(0) : '0'}% Fuel
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px] text-slate-950 dark:text-brand-text-secondary font-black">
                  <div className="truncate max-w-[140px] flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-gold animate-pulse"></div>
                    {bus.route_name}
                  </div>
                  <span className="flex items-center gap-1.5 bg-slate-100 dark:bg-brand-purple-card px-2.5 py-1 rounded-lg border border-slate-200 dark:border-brand-purple-dark/50"><Users className="w-3.5 h-3.5 text-brand-gold"/> {bus.occupancy}/{bus.capacity}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {alerts.length > 0 && (
          <section>
            <p className="text-[10px] font-black text-brand-gold dark:text-brand-gold uppercase tracking-[0.25em] mb-6 flex items-center gap-3">
              <span className="w-8 h-[2px] bg-brand-gold/20 dark:bg-brand-gold/30 rounded-full"></span>
              Alerts
            </p>
            <div className="space-y-4">
              {alerts.map((alert, i) => (
                <div key={i} className="bg-brand-gold/5 dark:bg-brand-gold/10 border border-brand-gold/20 dark:border-brand-gold/30 p-5 rounded-2xl text-[11px] font-bold text-brand-purple-dark dark:text-brand-gold-soft shadow-sm flex gap-3">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-brand-gold" />
                  {alert.message}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      <div className="p-4 md:p-6 border-t border-slate-100 dark:border-brand-purple-dark bg-slate-100 dark:bg-brand-purple-card/50">
        <button
          onClick={logout}
          className="flex items-center justify-center gap-3 w-full p-4 bg-white dark:bg-brand-purple-dark text-slate-900 dark:text-white hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 hover:border-red-100 dark:hover:border-red-900/30 border border-slate-200 dark:border-brand-purple-card rounded-2xl transition-all shadow-sm font-extrabold text-sm uppercase tracking-widest active:scale-[0.98]"
        >
          <LogOut className="w-5 h-5" />
          <span>{t('logout')}</span>
        </button>
      </div>
    </aside>
  );
};
