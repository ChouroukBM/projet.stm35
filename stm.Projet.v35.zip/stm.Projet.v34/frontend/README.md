# Saida Transit Monitor (STM)

A full-stack real-time public bus monitoring system for Saida, Algeria.

## Features

- **Real-time Map**: Live tracking of buses across Saida using Leaflet.js and Socket.io.
- **Map Layers**: Toggle between street view, satellite, and dark mode.
- **Role-based Auth**: Admin and Regular User dashboards using JWT.
- **Simulation Engine**: Backend simulation of bus movements, occupancy changes, and fuel consumption.
- **Alerts & Complaints**: Users can submit reports; admins receive real-time notifications.
- **Analytics**: Real-time charts for fleet occupancy and fuel levels.

## Tech Stack

- **Frontend**: React, Tailwind CSS, Recharts, React-Leaflet
- **Backend**: Node.js, Express, Socket.io
- **Database**: SQLite (used for zero-config setup in this environment, easily swappable to PostgreSQL)

## How to Run Locally (MacBook / Linux / Windows)

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```
   This will start both the Express backend and the Vite frontend concurrently.

3. **Build for Production**
   ```bash
   npm run build
   npm start
   ```

## Demo Accounts

- **Admin**: `admin@stm.dz` / `admin123`
- **User**: `user@stm.dz` / `user123`

## Database Note
The project uses `better-sqlite3` for an out-of-the-box working experience without requiring a separate database server installation. The schema and queries are standard SQL and can be easily migrated to PostgreSQL by swapping the database driver (e.g., using `pg` or an ORM like Prisma/Sequelize).
