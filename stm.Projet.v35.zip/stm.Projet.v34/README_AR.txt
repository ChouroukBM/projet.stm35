STM Projet v31 - Frontend + Backend منفصلين

المهم:
- الحافلات الأصلية محفوظة كما هي: 7 حافلات من src/data/busesData.ts
- الخريطة، المحطات، المسارات، localisation، nearest stop والـ simulation لم يتم تغييرها.
- تم فصل Back-End في مجلد backend.
- Login/Register حقيقي عبر Back-End + SQLite + bcrypt + JWT Token.

طريقة التشغيل في VS Code:

1) Terminal 1 - Backend:
cd backend
npm install
npm start

يجب أن يظهر:
STM Back-End API running on http://localhost:3001

2) Terminal 2 - Frontend:
cd frontend
npm install
npm run dev

افتحي:
http://localhost:3000

اختبار سريع:
- افتحي http://localhost:3001/buses للتأكد من وجود 7 حافلات.
- في الموقع اضغطي Sign Up وسجلي email/password جديدين.
- ثم Login بنفس الحساب.

ملاحظات تقنية:
- Frontend يستعمل /api/auth/login و /api/auth/register.
- Vite proxy يرسل /api و /socket.io إلى http://localhost:3001.
- Token يُحفظ في localStorage باسم stm_token.
