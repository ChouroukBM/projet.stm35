import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import type { Database } from "better-sqlite3";

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key-for-stm";

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const db = req.app.locals.db as Database;

  try {
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user) {
      return res.status(401).json({ error: "Account not found. Invalid email address." });
    }

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Wrong password. Please try again." });
    }

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: "1d" });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/admin-login", (req, res) => {
  const { email, password } = req.body;
  const db = req.app.locals.db as Database;

  try {
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user) {
      return res.status(401).json({ error: "Account not found. Invalid email address." });
    }

    if (user.role !== "admin") {
      return res.status(403).json({ error: "Access denied. Admin privileges required." });
    }

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: "Wrong password. Please try again." });
    }

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: "1d" });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/register", (req, res) => {
  const { name, email, password } = req.body;
  const db = req.app.locals.db as Database;

  try {
    const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (existing) {
      return res.status(400).json({ error: "Email already in use." });
    }

    const hash = bcrypt.hashSync(password, 10);
    // Hardcode role to 'user' to prevent privilege escalation
    const insert = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
    const result = insert.run(name, email, hash);

    const token = jwt.sign({ id: result.lastInsertRowid, role: 'user', name }, JWT_SECRET, { expiresIn: "1d" });
    res.status(201).json({ token, user: { id: result.lastInsertRowid, name, email, role: 'user' } });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/forgot-password", (req, res) => {
  const { email } = req.body;
  const db = req.app.locals.db as Database;

  try {
    const user = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
    if (!user) {
      return res.status(404).json({ error: "Account does not exist." });
    }
    // Simulate sending email
    res.json({ message: "Password reset link sent to your email." });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/me", (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const db = req.app.locals.db as Database;
    const user = db.prepare("SELECT id, name, email, role FROM users WHERE id = ?").get(decoded.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(401).json({ error: "Invalid token" });
  }
});

export default router;
