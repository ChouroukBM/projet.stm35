import express from "express";
import type { Database } from "better-sqlite3";
import jwt from "jsonwebtoken";

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || "super-secret-key-for-stm";

// Middleware to check auth
const authMiddleware = (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: "Invalid token" });
  }
};

router.post("/", authMiddleware, (req: any, res: any) => {
  const { bus_id, category, bus_type, description } = req.body;
  const db = req.app.locals.db as Database;
  
  try {
    const insert = db.prepare("INSERT INTO complaints (user_id, bus_id, category, bus_type, description) VALUES (?, ?, ?, ?, ?)");
    const result = insert.run(req.user.id, bus_id, category, bus_type, description);
    
    // Notify admins via socket
    req.app.locals.io.emit("new_complaint", {
      id: result.lastInsertRowid,
      user_id: req.user.id,
      user_name: req.user.name,
      bus_id,
      category,
      bus_type,
      description,
      status: "pending",
      created_at: new Date().toISOString()
    });

    res.status(201).json({ id: result.lastInsertRowid });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/", authMiddleware, (req: any, res: any) => {
  const db = req.app.locals.db as Database;
  try {
    let complaints;
    if (req.user.role === "admin") {
      complaints = db.prepare(`
        SELECT c.*, u.name as user_name, b.plate_number as bus_plate
        FROM complaints c
        LEFT JOIN users u ON c.user_id = u.id
        LEFT JOIN buses b ON c.bus_id = b.id
        ORDER BY c.created_at DESC
      `).all();
    } else {
      complaints = db.prepare(`
        SELECT c.*, b.plate_number as bus_plate
        FROM complaints c
        LEFT JOIN buses b ON c.bus_id = b.id
        WHERE c.user_id = ?
        ORDER BY c.created_at DESC
      `).all(req.user.id);
    }
    res.json(complaints);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
