import express from "express";
import type { Database } from "better-sqlite3";

const router = express.Router();

const normalizeBusPayload = (body: any) => {
  const status = body.status || "working";
  const capacity = Number(body.capacity ?? 40);
  const passengers = status === "out_of_service"
    ? 0
    : Math.max(0, Math.min(capacity, Number(body.passengers ?? 0)));

  return {
    plate_number: body.plate_number || body.number || "New Bus",
    route_name: body.route_name || "manual",
    driver_name_en: body.driver_name_en || body.driver_name || "",
    driver_name_fr: body.driver_name_fr || body.driver_name || "",
    driver_name_ar: body.driver_name_ar || body.driver_name || "",
    receveur_name_en: body.receveur_name_en || body.receveur_name || "Receveur non affecté",
    receveur_name_fr: body.receveur_name_fr || body.receveur_name || "Receveur non affecté",
    receveur_name_ar: body.receveur_name_ar || body.receveur_name || "قابض غير معيّن",
    capacity,
    passengers,
    eta_en: body.eta_en || body.eta || "5 min",
    eta_fr: body.eta_fr || body.eta || "5 min",
    eta_ar: body.eta_ar || body.eta || "5 دقائق",
    from_en: body.from_en || body.from || "",
    from_fr: body.from_fr || body.from || "",
    from_ar: body.from_ar || body.from || "",
    to_en: body.to_en || body.to || "",
    to_fr: body.to_fr || body.to || "",
    to_ar: body.to_ar || body.to || "",
    lat: Number(body.lat ?? 34.8308),
    lng: Number(body.lng ?? 0.1496),
    stops_list: body.stops_list || "[]",
    bus_type: body.bus_type || "Standard",
    next_maintenance_date: body.next_maintenance_date || null,
    maintenance_note: body.maintenance_note || "",
    status,
  };
};

const broadcastBuses = (req: express.Request) => {
  const db = req.app.locals.db as Database;
  const io = req.app.locals.io;
  const buses = db.prepare("SELECT * FROM buses ORDER BY id ASC").all();
  io?.emit("bus_positions", buses);
};

router.get("/", (req, res) => {
  const db = req.app.locals.db as Database;
  try {
    const buses = db.prepare("SELECT * FROM buses ORDER BY id ASC").all();
    res.json(buses);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/", (req, res) => {
  const db = req.app.locals.db as Database;
  try {
    const bus = normalizeBusPayload(req.body);
    const result = db.prepare(`
      INSERT INTO buses (
        plate_number, route_name,
        driver_name_en, driver_name_fr, driver_name_ar,
        receveur_name_en, receveur_name_fr, receveur_name_ar,
        capacity, passengers,
        eta_en, eta_fr, eta_ar,
        from_en, from_fr, from_ar,
        to_en, to_fr, to_ar,
        lat, lng, stops_list, bus_type,
        next_maintenance_date, maintenance_note, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      bus.plate_number, bus.route_name,
      bus.driver_name_en, bus.driver_name_fr, bus.driver_name_ar,
      bus.receveur_name_en, bus.receveur_name_fr, bus.receveur_name_ar,
      bus.capacity, bus.passengers,
      bus.eta_en, bus.eta_fr, bus.eta_ar,
      bus.from_en, bus.from_fr, bus.from_ar,
      bus.to_en, bus.to_fr, bus.to_ar,
      bus.lat, bus.lng, bus.stops_list, bus.bus_type,
      bus.next_maintenance_date, bus.maintenance_note, bus.status
    );

    const created = db.prepare("SELECT * FROM buses WHERE id = ?").get(result.lastInsertRowid);
    broadcastBuses(req);
    res.status(201).json(created);
  } catch (err: any) {
    if (String(err?.message || "").includes("UNIQUE")) {
      return res.status(400).json({ error: "This bus plate already exists." });
    }
    res.status(500).json({ error: "Server error" });
  }
});

router.put("/:id", (req, res) => {
  const db = req.app.locals.db as Database;
  try {
    const existing = db.prepare("SELECT * FROM buses WHERE id = ?").get(req.params.id) as any;
    if (!existing) return res.status(404).json({ error: "Bus not found" });

    const bus = normalizeBusPayload({ ...existing, ...req.body });
    db.prepare(`
      UPDATE buses SET
        plate_number = ?, route_name = ?,
        driver_name_en = ?, driver_name_fr = ?, driver_name_ar = ?,
        receveur_name_en = ?, receveur_name_fr = ?, receveur_name_ar = ?,
        capacity = ?, passengers = ?,
        eta_en = ?, eta_fr = ?, eta_ar = ?,
        from_en = ?, from_fr = ?, from_ar = ?,
        to_en = ?, to_fr = ?, to_ar = ?,
        lat = ?, lng = ?, stops_list = ?, bus_type = ?,
        next_maintenance_date = ?, maintenance_note = ?, status = ?
      WHERE id = ?
    `).run(
      bus.plate_number, bus.route_name,
      bus.driver_name_en, bus.driver_name_fr, bus.driver_name_ar,
      bus.receveur_name_en, bus.receveur_name_fr, bus.receveur_name_ar,
      bus.capacity, bus.passengers,
      bus.eta_en, bus.eta_fr, bus.eta_ar,
      bus.from_en, bus.from_fr, bus.from_ar,
      bus.to_en, bus.to_fr, bus.to_ar,
      bus.lat, bus.lng, bus.stops_list, bus.bus_type,
      bus.next_maintenance_date, bus.maintenance_note, bus.status,
      req.params.id
    );

    const updated = db.prepare("SELECT * FROM buses WHERE id = ?").get(req.params.id);
    broadcastBuses(req);
    res.json(updated);
  } catch (err: any) {
    if (String(err?.message || "").includes("UNIQUE")) {
      return res.status(400).json({ error: "This bus plate already exists." });
    }
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/stops", (req, res) => {
  const db = req.app.locals.db as Database;
  try {
    const stops = db.prepare("SELECT * FROM stops ORDER BY id ASC").all();
    res.json(stops);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
