import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";
import { stopsData } from "../src/data/stopsData.js";
import { busesData } from "../src/data/busesData.js";
import { routesData } from "../src/data/routesData.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function initDb() {
  const dbPath = path.join(process.cwd(), "stm.db");
  const db = new Database(dbPath);

  db.pragma("journal_mode = WAL");

  // Create tables and keep existing operational data whenever possible.
  // This is important because the admin can now edit buses from the dashboard.

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user'
    );

    CREATE TABLE IF NOT EXISTS buses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      plate_number TEXT UNIQUE NOT NULL,
      route_name TEXT NOT NULL,
      driver_name_en TEXT,
      driver_name_fr TEXT,
      driver_name_ar TEXT,
      capacity INTEGER NOT NULL,
      passengers INTEGER DEFAULT 0,
      eta_en TEXT,
      eta_fr TEXT,
      eta_ar TEXT,
      from_en TEXT,
      from_fr TEXT,
      from_ar TEXT,
      to_en TEXT,
      to_fr TEXT,
      to_ar TEXT,
      lat REAL,
      lng REAL,
      stops_list TEXT,
      bus_type TEXT DEFAULT 'Standard',
      receveur_name_en TEXT,
      receveur_name_fr TEXT,
      receveur_name_ar TEXT,
      next_maintenance_date TEXT,
      maintenance_note TEXT,
      status TEXT DEFAULT 'working'
    );

    CREATE TABLE IF NOT EXISTS stops (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      id_str TEXT UNIQUE,
      name_en TEXT,
      name_fr TEXT,
      name_ar TEXT,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      bus_id INTEGER,
      category TEXT NOT NULL,
      bus_type TEXT,
      description TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(bus_id) REFERENCES buses(id)
    );
  `);

  const ensureColumn = (table: string, column: string, definition: string) => {
    const columns = db.prepare(`PRAGMA table_info(${table})`).all() as any[];
    if (!columns.some(col => col.name === column)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    }
  };

  ensureColumn('buses', 'receveur_name_en', 'TEXT');
  ensureColumn('buses', 'receveur_name_fr', 'TEXT');
  ensureColumn('buses', 'receveur_name_ar', 'TEXT');
  ensureColumn('buses', 'next_maintenance_date', 'TEXT');
  ensureColumn('buses', 'maintenance_note', 'TEXT');
  ensureColumn('buses', 'bus_type', "TEXT DEFAULT 'Standard'");
  ensureColumn('buses', 'status', "TEXT DEFAULT 'working'");

  // Seed initial users if missing
  const adminExists = db.prepare("SELECT id FROM users WHERE email = ?").get("admin@stm.dz");
  if (!adminExists) {
    const insertUser = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    const adminHash = bcrypt.hashSync("admin123", 10);
    insertUser.run("Admin User", "admin@stm.dz", adminHash, "admin");
  }

  const userExists = db.prepare("SELECT id FROM users WHERE email = ?").get("user@stm.dz");
  if (!userExists) {
    const insertUser = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
    const userHash = bcrypt.hashSync("user123", 10);
    insertUser.run("Regular User", "user@stm.dz", userHash, "user");
  }

  // Upsert stops without deleting existing operational tables.
  const insertStop = db.prepare(`
    INSERT INTO stops (id, id_str, name_en, name_fr, name_ar, latitude, longitude)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id_str) DO UPDATE SET
      name_en = excluded.name_en,
      name_fr = excluded.name_fr,
      name_ar = excluded.name_ar,
      latitude = excluded.latitude,
      longitude = excluded.longitude
  `);
  for (const stop of (stopsData as any[])) {
    insertStop.run(stop.id, stop.id_str, stop.name_en, stop.name_fr, stop.name_ar, stop.latitude, stop.longitude);
  }

  const busCount = (db.prepare("SELECT COUNT(*) as count FROM buses").get() as any).count;
  if (busCount === 0) {
    const insertBus = db.prepare(`
      INSERT INTO buses (
        id, plate_number, route_name,
        driver_name_en, driver_name_fr, driver_name_ar,
        capacity, passengers,
        eta_en, eta_fr, eta_ar,
        from_en, from_fr, from_ar,
        to_en, to_fr, to_ar,
        lat, lng, stops_list, status,
        receveur_name_en, receveur_name_fr, receveur_name_ar,
        next_maintenance_date, maintenance_note
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    (busesData as any[]).forEach((bus) => {
      const route = (routesData as any[]).find(r => r.id === bus.routeId);
      const routeStops = (route?.stops || []).map((sid: string) => {
        const stop = (stopsData as any[]).find(s => s.id_str === sid);
        return {
          id_str: sid,
          name_en: stop?.name_en || sid,
          name_fr: stop?.name_fr || sid,
          name_ar: stop?.name_ar || sid
        };
      });

      insertBus.run(
        bus.id,
        bus.number,
        route?.id || "Unknown",
        bus.driver_en || "",
        bus.driver_fr || "",
        bus.driver_ar || "",
        bus.capacity,
        bus.status === 'out_of_service' ? 0 : (bus.passengers || 0),
        bus.eta_en || "5 min",
        bus.eta_fr || "5 min",
        bus.eta_ar || "5 دقائق",
        route?.from_en || "",
        route?.from_fr || "",
        route?.from_ar || "",
        route?.to_en || "",
        route?.to_fr || "",
        route?.to_ar || "",
        bus.lat,
        bus.lng,
        JSON.stringify(routeStops),
        bus.status || 'working',
        bus.receveur_en || "Receveur non affecté",
        bus.receveur_fr || "Receveur non affecté",
        bus.receveur_ar || "قابض غير معيّن",
        bus.next_maintenance_date || null,
        bus.maintenance_note || ""
      );
    });
  }

  // Normalize old rows: an out-of-service bus must not show active occupancy.
  db.prepare("UPDATE buses SET passengers = 0 WHERE status = 'out_of_service'").run();
  db.prepare("UPDATE buses SET receveur_name_en = COALESCE(receveur_name_en, 'Receveur non affecté')").run();
  db.prepare("UPDATE buses SET receveur_name_fr = COALESCE(receveur_name_fr, receveur_name_en)").run();
  db.prepare("UPDATE buses SET receveur_name_ar = COALESCE(receveur_name_ar, receveur_name_en)").run();
  db.prepare("UPDATE buses SET maintenance_note = COALESCE(maintenance_note, '')").run();
  return db;
}
