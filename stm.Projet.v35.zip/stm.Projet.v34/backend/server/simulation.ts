import type { Database } from "better-sqlite3";
import type { Server } from "socket.io";

export function startSimulation(db: Database, io: Server) {
  const stops = db.prepare("SELECT * FROM stops").all() as any[];
  const stopsMap = new Map(stops.map(s => [s.id_str, s]));
  if (stops.length === 0) return;

  const busPositions = new Map<number, any>();

  const hydrateBus = (bus: any) => {
    const existing = busPositions.get(bus.id);
    const routeStopsRaw = JSON.parse(bus.stops_list || "[]");
    const routeStops = routeStopsRaw.map((s: any) => stopsMap.get(s.id_str)).filter(Boolean);
    const effectiveStops = routeStops.length > 0 ? routeStops : stops;

    const frozen = bus.status === "out_of_service";
    const occupancy = frozen ? 0 : (existing?.occupancy ?? bus.passengers ?? Math.floor(Math.random() * Math.max(1, bus.capacity)));

    return {
      ...(existing || {}),
      ...bus,
      lat: frozen ? (existing?.lat ?? bus.lat ?? effectiveStops[0].latitude) : (existing?.lat ?? bus.lat ?? effectiveStops[0].latitude),
      lng: frozen ? (existing?.lng ?? bus.lng ?? effectiveStops[0].longitude) : (existing?.lng ?? bus.lng ?? effectiveStops[0].longitude),
      targetInRouteIndex: existing?.targetInRouteIndex ?? 0,
      speed: existing?.speed ?? 0.0002,
      occupancy,
      passengers: frozen ? 0 : (bus.passengers ?? occupancy),
      fuel: frozen ? 0 : bus.status === "delayed" ? 62 : (existing?.fuel ?? 85)
    };
  };

  setInterval(() => {
    const dbBuses = db.prepare("SELECT * FROM buses ORDER BY id ASC").all() as any[];

    // Add/update current simulation state from database so admin edits are reflected live.
    dbBuses.forEach(bus => busPositions.set(bus.id, hydrateBus(bus)));

    // Remove deleted buses from state, if any are deleted later.
    const dbIds = new Set(dbBuses.map(bus => bus.id));
    Array.from(busPositions.keys()).forEach(id => {
      if (!dbIds.has(id)) busPositions.delete(id);
    });

    const positions = Array.from(busPositions.values());

    positions.forEach(bus => {
      // A bus out of service must not move and must not update occupancy.
      if (bus.status === "out_of_service") {
        bus.occupancy = 0;
        bus.passengers = 0;
        return;
      }

      const routeStopsRaw = JSON.parse(bus.stops_list || "[]");
      const routeStops = routeStopsRaw.map((s: any) => stopsMap.get(s.id_str)).filter(Boolean);
      const effectiveStops = routeStops.length > 0 ? routeStops : stops;
      const targetStop = effectiveStops[bus.targetInRouteIndex] || effectiveStops[0];

      const dx = targetStop.longitude - bus.lng;
      const dy = targetStop.latitude - bus.lat;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < bus.speed) {
        bus.lat = targetStop.latitude;
        bus.lng = targetStop.longitude;
        bus.targetInRouteIndex = (bus.targetInRouteIndex + 1) % effectiveStops.length;
        const change = Math.floor(Math.random() * 10) - 5;
        bus.occupancy = Math.max(0, Math.min(bus.capacity, bus.occupancy + change));
        bus.passengers = bus.occupancy;
      } else {
        bus.lng += (dx / dist) * bus.speed;
        bus.lat += (dy / dist) * bus.speed;
      }
    });

    io.emit("bus_positions", positions);
  }, 2000);
}
