export const routesData = [
  { id: "r1", bus: "Bus 07", from_en: "Université 2000", from_fr: "Université 2000", from_ar: "جامعة 2000", to_en: "Paramédical", to_fr: "Paramédical", to_ar: "شبه طبي", stops: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"] },
  { id: "r2", bus: "Bus 13", from_en: "Université 2000", from_fr: "Université 2000", from_ar: "جامعة 2000", to_en: "UNS (Tunnel)", to_fr: "UNS (Tunnel)", to_ar: "UNS (النفق)", stops: ["1", "2", "3", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"] },
  { id: "r3", bus: "Bus 16", from_en: "Cité 2000 lits", from_fr: "Cité 2000 lits", from_ar: "حي 2000 سرير", to_en: "Dar Baida 02", to_fr: "Dar Baida 02", to_ar: "الدار البيضاء 02", stops: ["2", "4", "6", "20", "21", "22", "23"] },
  { id: "r4", bus: "Bus 02", from_en: "Paramédical", from_fr: "Paramédical", from_ar: "شبه طبي", to_en: "Bibliothèque ouanzar", to_fr: "Bibliothèque ouanzar", to_ar: "مكتبة وانزار", stops: ["15", "20", "21"] },
  { id: "r5", bus: "Bus 08", from_en: "Paramédical", from_fr: "Paramédical", from_ar: "شبه طبي", to_en: "Les Castors", to_fr: "Les Castors", to_ar: "لي كاستور", stops: ["15", "16", "17"] },
  { id: "r6", bus: "Bus 09", from_en: "Paramédical", from_fr: "Paramédical", from_ar: "شبه طبي", to_en: "Paramédical", to_fr: "Paramédical", to_ar: "شبه طبي", stops: ["15"] },
  { id: "r7", bus: "Bus 10", from_en: "Paramédical", from_fr: "Paramédical", from_ar: "شبه طبي", to_en: "Paramédical", to_fr: "Paramédical", to_ar: "شبه طبي", stops: ["15"] }
];
