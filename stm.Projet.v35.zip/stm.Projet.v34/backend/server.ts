import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";
import { initDb } from "./server/db.js";
import authRoutes from "./server/routes/auth.js";
import busRoutes from "./server/routes/buses.js";
import complaintRoutes from "./server/routes/complaints.js";
import { startSimulation } from "./server/simulation.js";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3001);
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:3000";

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: [FRONTEND_ORIGIN, "http://localhost:5173"],
    methods: ["GET", "POST", "PUT", "DELETE"],
  },
});

app.use(cors({ origin: [FRONTEND_ORIGIN, "http://localhost:5173"], credentials: true }));
app.use(express.json());

const db = initDb();
app.locals.db = db;
app.locals.io = io;

// Main API used by the Front-End
app.use("/api/auth", authRoutes);
app.use("/api/buses", busRoutes);
app.use("/api/complaints", complaintRoutes);

// Compatibility aliases for external tests or old docs
app.use("/auth", authRoutes);
app.post("/login", (req, res, next) => {
  req.url = "/login";
  return authRoutes(req, res, next);
});
app.post("/register", (req, res, next) => {
  req.url = "/register";
  return authRoutes(req, res, next);
});
app.get("/buses", (req, res, next) => {
  req.url = "/";
  return busRoutes(req, res, next);
});
app.get("/stops", (req, res, next) => {
  req.url = "/stops";
  return busRoutes(req, res, next);
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "STM API", buses: db.prepare("SELECT COUNT(*) as count FROM buses").get() });
});

startSimulation(db, io);

httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`STM Back-End API running on http://localhost:${PORT}`);
});
